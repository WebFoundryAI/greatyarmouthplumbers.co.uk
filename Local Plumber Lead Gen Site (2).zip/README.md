
  # Local Plumber Lead Gen Site

  This is a code bundle for Local Plumber Lead Gen Site. The original project is available at https://www.figma.com/design/Qztxsiev6E05HdoNom8eiJ/Local-Plumber-Lead-Gen-Site.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  